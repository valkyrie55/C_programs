
Part 1:- (Done)

1. Fetch all the urls from the listing page given above, sort it and store it in a csv.
2. Iterate over first 5 urls of csv to perform following operation on each of them:
	Make folder with the name of the product and save all the following screenshots in the same.
	i. take a screenshot of the page after visiting the link. Save it as "PDP.png"
	ii. take 2nd screenshot of the page after clicking on "Pay for your phone in one go" and then close the popup. Save it as "MSRP.png"
	iii. Click on "Build your Phone Plan".
	iv. then click on "I'm a new customer".
	v. then take 3rd screenshot of the page and Save it as "Phoneplan.png".
	vi. then click on "Continue". then on another page click on "NO" button.
	vii.then take the 4th screenshot of the page and save it as "Airtime.png"
3. Proper navigation of the site is given in the folder "Clicks".
4. Desired screenshots of a product is given in the folder "Sample".
	
-----------------------------------------------------------------------------------------------------------------------------------------

Part 2:- (Couldn't extract data in step 4 as more clarification required. I also faced a few challenges due to different UI's for different products within the website,
 tried to handle them but couldn't resolve all. Thus, didn't get the output in the required form. Thus, didn't attach the output file

The text that needs to be extracted is marked in the images in the folder named "Text Extraction"
Sample Screenshots is provided for Samsung Galaxy S23 model.

1. PDP.png : Extract "Product Name", "Memory", "Color", "Promotions" and "Shipment details" from this page.
             There can be More than one Promotions. In case of multiple promos append it to the "Promotions" column with newline character.

2. MSRP.png : Extract "MSRP USD"

3. Phoneplan.png : Extract "contract_length", "monthly_phoneplan", "Upfront".
                   Iterate over Upfront and contract_length. Each iteration will be added to new line of csv.

4. Airtime 1.png and Airtime 2.png : Iterate over 12 months and 24 months and extract "Rateplan Promotions",  "Plan Type", "monthly_airtimeplan",
 "Duration".