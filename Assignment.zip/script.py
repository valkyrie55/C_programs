#import necessary libraries
import os, time
import pandas as pd
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support import expected_conditions as EC

def read_page(i, url):
    options = webdriver.ChromeOptions()
    options.add_argument('--headless')
    driver = webdriver.Chrome(options = options)
    driver.get(url)
    time.sleep(5)
    #Handle cookie 
    driver.find_element(By.XPATH,'//button[@id="onetrust-accept-btn-handler"]').click()
    time.sleep(5)
    extract_product_details(driver)
    product_name = get_product_name(url, driver)
    #create a folder for the product
    os.chdir('C:\\Users\\Shweta\\Documents')
    os.mkdir(product_name)
    new_working_directory = path + '\\' + product_name
#     change the working direcrtory so as to save all screenshots inside the product's folder
    os.chdir(new_working_directory)
#     print("Folder created. current working direcrtory: ", os.getcwd())
    S = lambda X: driver.execute_script('return document.body.parentNode.scroll'+X)
    driver.set_window_size(S('Width')+255,S('Height')-2100)
    
    #taking first screenshot
    driver.find_element(By.TAG_NAME,'body').screenshot('PDP.png')
    print("first ss taken!")
    driver = pay_for_your_phone_in_one_go(driver)
    
    driver = build_your_phone_plan(driver)
    
    driver.find_element(By.TAG_NAME,'body').screenshot('Airtime.png')
    

def build_your_phone_plan(driver):
    #check whether is product is in stock
    element = driver.find_elements(By.XPATH,'//span[@class="vfuk-Button__content"]')
    if element[0].text == 'Out Of Stock' or element[6].text == 'Out Of Stock':
        upfront_list.append(' ')
        contract_length_list.append(' ')
        monthly_phoneplan_list.append(' ')
        return
    else:
        #click on "Build your Phone Plan"
        element = driver.find_elements(By.XPATH,'//button[@class="vfuk-Button__button vfuk-Button__primary margin-top-1 margin-bottom-1 margin-left-sm-0 margin-right-sm-0" ]')
        driver.execute_script("arguments[0].click();", element[2])
        #close cookies dialogue box
        time.sleep(5)
#         driver.find_element(By.XPATH,'//button[@id="onetrust-accept-btn-handler"]').click()
        # "I'm a new customer" 
        driver.find_element(By.XPATH,'//button[@class="Interactionstyle__Button-sc-e1xkgc-0 emPZAO Buttonstyle__Button-sc-twej8-0 hFBosM"]').click()
        time.sleep(5)
        
        driver.find_element(By.TAG_NAME,'body').screenshot('Phoneplan.png')
        
        #get phoneplan details
        extract_phoneplan_details(driver)

        # click on "Continue"
        driver.find_element(By.XPATH,'//button[@class="Interactionstyle__Button-sc-e1xkgc-0 emPZAO Buttonstyle__Button-sc-twej8-0 bjKNMI"]').click()
        # click on "NO" button
        driver.find_element(By.XPATH,'//button[@class="Interactionstyle__Button-sc-e1xkgc-0 emPZAO Buttonstyle__Button-sc-twej8-0 gpnJnU"]').click()
#         screenshot4(driver)
#         click_on_continue(driver)
     

#taking 2nd screenshot

def pay_for_your_phone_in_one_go(driver):
    #click on "Pay for your phone in one go"
    time.sleep(10)
    element = driver.find_element(By.XPATH,'//a[@class="vfuk-Link__inherit vfuk-Link__link  " and @data-di-id="di-id-eeb5254d-f8233344"]')
    driver.execute_script("arguments[0].click();", element)
    
    #close cookies dialogue box
    cookies = driver.find_element(By.XPATH,'//button[@id="onetrust-accept-btn-handler"]')
    driver.execute_script("arguments[0].click();", cookies)
    
#     driver.find_element(By.XPATH,'//button[@id="onetrust-accept-btn-handler"]').click()
    time.sleep(4)
    
    #extract MSRP
    get_msrp(driver)
    
    #taking second screenshot
    driver.find_element(By.TAG_NAME,'body').screenshot("MSRP.png")
    time.sleep(4)
    
    #hit the close button
    driver.find_element(By.XPATH,'//button[@class="vfuk-Modal__close"]').click()
    return driver

def get_product_name(url, driver):
    name_list = driver.find_elements(By.XPATH,'//h1[@class="Headingstyle__Heading-sc-12vluu2-0 iPleXT"]')
    product_name = name_list[2].text
    return product_name  

def extract_product_details(driver):
    name_list = driver.find_elements(By.XPATH,'//h1[@class="Headingstyle__Heading-sc-12vluu2-0 iPleXT"]')
    product_name_list.append(name_list[0].text)
    print("Product name: ",name_list[0].text)
   
    # In products with no dropdown values in memory/color, the class is different, thus the xpath will not give
    # correct result
    
    memory_list = driver.find_elements(By.XPATH,'//select[@class="vfuk-Select__select"]')
    if len(memory_list) == 0: #no dropdown is there, hence change xpath
        memory_list = driver.find_elements(By.XPATH, '//div[@class="vfuk-capacitySelect__variantSingle"]')
    product_memory_list.append(memory_list[0].text)
        
    colors_list = driver.find_elements(By.XPATH,'//select[@class="vfuk-Select__select"]')
    if len(colors_list) == 0:
        colors_list = driver.find_elements(By.XPATH,'//div[@class="vfuk-colourSelect__variantSingle"]')
    product_color_list.append(colors_list[0].text)
    shipment_details_list = driver.find_elements(By.XPATH,'//div[@class="RawHtmlWrapperstyle__HtmlWrapper-sc-848srh-0 jcqXHD"]')
    product_shipment_details_list.append(shipment_details_list[0].text)
    promotions_details = driver.find_elements(By.XPATH,'//span[@class="samsung-disney-plus-promo__heading vfuk-Heading__heading vfuk-Heading__heading-3 vfuk-Heading__inherit w-bold"]')
    if len(promotions_details) == 0:
        product_promotions_details_list.append(' ')
    else:
        product_promotions_details_list.append(promotions_details[0].text)
    

def get_msrp(driver):
    #to be executed after clicking on: 
#     element = driver.find_element(By.XPATH,'//a[@class="vfuk-Link__inherit vfuk-Link__link  " and @data-di-id="di-id-eeb5254d-f8233344"]')
#     driver.execute_script("arguments[0].click();", element)
    n = driver.find_elements(By.TAG_NAME, 'strong')
    msrp_list.append(n[-1].text)
    print("MSRP: ", n[-1].text)

def extract_phoneplan_details(driver):
    l = driver.find_elements(By.XPATH,'//span[@class="StepperValuestyle__ValueLabel-sc-129x7bs-1 biFhtK"]')
    upfront = l[0].text
    contract_length = l[1].text
    upfront_list.append(upfront)
    contract_length_list.append(contract_length)
    monthly_phoneplan = driver.find_element(By.XPATH,'//span[@class="SimplifiedConfiguratorTotalCoststyle__Price-sc-16r3vpg-4 jtFGpT"]')
    monthly_phoneplan_list.append(monthly_phoneplan.text)


############################################################################################

path = 'C:\\Users\\Shweta\\Documents'

#create the driver object
driver = webdriver.Chrome()

# # link of the webpage
url = 'https://www.vodafone.co.uk/mobile/phones/pay-monthly-contracts'
driver.get(url)

time.sleep(10)

#handle cookie dialogue box
browser.find_element(By.XPATH,'//button[@id="onetrust-accept-btn-handler"]').click()

#fetching all the 115 links and storing in .csv file
time.sleep(2)
# wait for 1sec after scrolling
scroll_wait = 5

# fetch the screen height
screen_height = browser.execute_script("return window.screen.height;")
browser.implicitly_wait(60) 

ScrollNumber = 1

res = set()

while True:
    # Scrolling one screen at a time until
    browser.execute_script(f"window.scrollTo(0, {screen_height * ScrollNumber})")
    ScrollNumber += 1
    
    # Wait for some time after scrolling
    time.sleep(scroll_wait)
    
    # Update the scroll_height after each scroll
    scroll_height = browser.execute_script("return document.body.scrollHeight;")
    
    # Fetching the links
    all_urls = browser.find_elements(By.XPATH, "//a[@class = 'vfuk-DeviceCard__wrapper vfuk-DeviceCard__wrapper__with-bottom-row']")
    for i in all_urls:
        if i.get_attribute("href") not in ans:
            ans.add(i.get_attribute("href"))
    # stop when we reach the end of the page
    if (screen_height) * ScrollNumber > scroll_height:
        break

#handle the 'Help me choose' dialogue box -> clicking on "Not Now"
browser.find_element(By.XPATH,'//button[@data-testid="_15gifts-engagement-bubble-button-secondary"]').click()

urls = list(res)

#convert into df
links = pd.DataFrame({'link': urls })
links.to_csv('links.csv')
#step 1 done

df = pd.read_csv("C:\\Users\\Shweta\\Documents\\links.csv")

all_url_list = []
product_name_list = []
product_memory_list = []
product_color_list = []
product_shipment_details_list = []
product_promotions_details_list = []
msrp_list = []
upfront_list = []
contract_length_list = []
monthly_phoneplan_list = []

#iterating over first 5 urls
os.chdir('C:\\Users\\Shweta\\Documents')
for i in range(1,5):
    url = df['link'].iloc[i]
    all_url_list.append(url)
    print("url: ",url)
    read_page(i, url)

output = pd.DataFrame({
    'Product Name': product_name_list,
'Memory': product_memory_list,
'Color': product_color_list,
'MSRP USD': msrp_list,
'Promotions': product_promotions_details_list ,
'contract_length': contract_length_list,
'monthly_phoneplan': monthly_phoneplan_list ,
'Upfront': upfront_list,
'Shipment details': product_shipment_details_list,
'Upfront': upfront_list ,
'Product URL': all_url_list
})
links.to_csv('Phoneplan.csv')

